# DeepSeek-Local
A Python package to install and run DeepSeek-Coder locally using Ollama.

## Installation
```bash
pip install deepseek_local