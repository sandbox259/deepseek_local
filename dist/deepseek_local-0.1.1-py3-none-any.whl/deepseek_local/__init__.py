# Import functions to make them available at the package level
from .deepseek import run_deepseek, install_deepseek
from .utils import is_ollama_installed, install_ollama
